from flask import Flask, request, render_template, redirect, url_for
import os
import time
import cv2
import imghdr
import numpy as np
import uuid
import joblib

app = Flask(__name__)
# Cargar el modelo SVM RBF desde el archivo .pkl
modelo_entrenado = 'modelo20231010_RBF_prob.pkl'
clf = joblib.load(modelo_entrenado)

def calcular_asimetria(imagen):
    # Código para calcular la asimetría
    imagen_gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
    asimetria = np.sum(np.abs(imagen_gris - np.flip(imagen_gris))) / (2 * imagen_gris.size)
    return asimetria

def calcular_variacion_color(imagen):
    # Código para calcular la variación de color
    imagen_hsv = cv2.cvtColor(imagen, cv2.COLOR_BGR2HSV)
    canal_saturacion = imagen_hsv[:, :, 1]
    desviacion_estandar = np.std(canal_saturacion)
    return desviacion_estandar

def calcular_borde_irisado(imagen):
    # Código para calcular el borde irisado
    imagen_gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
    bordes = cv2.Canny(imagen_gris, 100, 200)
    valor_promedio = cv2.mean(imagen_gris, mask=bordes)[0]
    return valor_promedio

def calcular_diametro(imagen):
    # Código para calcular el diámetro
    imagen_gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
    _, imagen_binaria = cv2.threshold(imagen_gris, 0, 255, cv2.THRESH_BINARY)
    contornos, _ = cv2.findContours(imagen_binaria, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contorno_principal = max(contornos, key=cv2.contourArea)
    puntos_extremos = contorno_principal[:, 0, :]
    punto_izquierdo = puntos_extremos[np.argmin(puntos_extremos[:, 0])]
    punto_derecho = puntos_extremos[np.argmax(puntos_extremos[:, 0])]
    diametro = np.linalg.norm(punto_derecho - punto_izquierdo)
    return diametro

def extraer_caracteristicas_imagen(archivo_origen, archivo_destino):
    imagen = cv2.imread(archivo_origen)
    asimetria = calcular_asimetria(imagen)
    variacion_color = calcular_variacion_color(imagen)
    diametro = calcular_diametro(imagen)
    valor_bordes = calcular_borde_irisado(imagen)
    with open(archivo_destino, "w") as archivo_txt:
        archivo_txt.write(f"Asimetria: {asimetria:.4f}\n")
        archivo_txt.write(f"Color: {variacion_color:.4f}\n")
        archivo_txt.write(f"Diametro: {diametro}\n")
        archivo_txt.write(f"Bordes: {valor_bordes:.4f}\n")

def analizar_txt(ruta_archivo):
    # Leer el archivo de texto y analizar sus contenidos
    with open(ruta_archivo, "r") as archivo_txt:
        lineas = archivo_txt.readlines()
        caracteristicas = {}
        for linea in lineas:
            clave, valor = linea.strip().split(": ")
            caracteristicas[clave] = valor

        # Realizar el análisis, por ejemplo, determinar la probabilidad de Melanoma
        asimetria = float(caracteristicas.get("Asimetria", 0))
        variacion_color = float(caracteristicas.get("Color", 0))
        diametro = float(caracteristicas.get("Diametro", 0))
        bordes = float(caracteristicas.get("Bordes", 0))
        edad = float(caracteristicas.get("Edad", 50))  # Valor predeterminado de 50 si no se encuentra

        # Realizar aquí el análisis necesario para obtener la probabilidad
        caracteristicas_a_analizar = np.array([asimetria, variacion_color, diametro, bordes, edad]).reshape(1, -1)
        probabilidad_melanoma = clf.predict_proba(caracteristicas_a_analizar)[:, 1][0] * 100  # Probabilidad en porcentaje

        return probabilidad_melanoma


@app.route("/", methods=["GET", "POST"])
def index():
    imagen_nombre = None
    probabilidad_melanoma = None

    if request.method == "POST":
        # Guarda la imagen subida en una ubicación temporal
        imagen = request.files["imagen"]
        if imagen:
            imagen.save("temp.png")
            # Llama a la función de procesamiento de la Fase 1 con la imagen
            ruta_procesada_fase1 = procesar_fase1("temp.png")

            # Llama a la función de procesamiento de la Fase 2 con la imagen resultante de la Fase 1
            ruta_procesada_fase2 = procesar_fase2(ruta_procesada_fase1)

            # Llama a la función de procesamiento de la Fase 3 con la imagen resultante de la Fase 2
            ruta_procesada_fase3 = procesar_fase3(ruta_procesada_fase2)

            # Llama a la función de procesamiento de la Fase 4 para extraer características
            archivo_origen_fase4 = ruta_procesada_fase3

            # Generar un nombre único para el archivo de características usando uuid
            nombre_unico = str(uuid.uuid4())[:8]  # Genera un identificador único de 8 caracteres
            archivo_destino_fase4 = f"C:/Users/Administrator/Desktop/destino/caracteristicas_{nombre_unico}.txt"

            extraer_caracteristicas_imagen(archivo_origen_fase4, archivo_destino_fase4)

            # Obtener el nombre de la imagen subida
            imagen_nombre = imagen.filename  # Aquí asumo que el objeto 'imagen' contiene el nombre del archivo subido

            # Realizar el análisis del archivo de características
            resultado_analisis = analizar_txt(archivo_destino_fase4)
            probabilidad_melanoma = resultado_analisis
            return render_template("resultado.html", imagen_nombre=imagen_nombre, probabilidad_melanoma=probabilidad_melanoma)

            # Llama a la función de análisis del archivo de texto
            #resultado_analisis = analizar_txt(archivo_destino_fase4)
            #return f"Fase 4 completada con éxito. Resultado del análisis: Melanoma - porcentaje de probabilidad {resultado_analisis:.2f}%"

        else:
            return "No se ha cargado ninguna imagen."
    return render_template("index.html")


def procesar_fase1(imagen_path):
    # Coloca aquí el código de procesamiento de la Fase 1
    from PIL import Image, ImageEnhance, ImageFilter

    # Ruta de la imagen de origen y destino
    ruta_original = imagen_path
    ruta_destino_procesado = imagen_path  # Puedes cambiar la ruta de destino si es necesario

    # Procesar la imagen
    imagen = Image.open(ruta_original)
    ancho, alto = imagen.size

    # Definir las dimensiones límite
    alto_minimo = 1100
    alto_maximo = 1500

    # Calcular nuevo alto manteniendo la relación de aspecto
    nuevo_alto = min(max(alto, alto_minimo), alto_maximo)
    nuevo_ancho = int(ancho * nuevo_alto / alto)

    # Redimensionar la imagen original a las nuevas dimensiones
    imagen_redimensionada = imagen.resize((nuevo_ancho, nuevo_alto), resample=Image.LANCZOS)

    # Aplicar filtro de enfoque a los bordes
    imagen_enfocada = imagen_redimensionada.filter(ImageFilter.UnsharpMask(radius=2, percent=150, threshold=3))

    # Aumentar el contraste de la imagen
    factor_contraste = 1.2  # Ajusta este valor para aumentar o disminuir el contraste
    realce_contraste = ImageEnhance.Contrast(imagen_enfocada)
    imagen_contraste = realce_contraste.enhance(factor_contraste)

    # Ajustar el brillo de la imagen
    factor_brillo = 0.7  # Ajusta este valor para hacer la imagen más oscura (0.0 - 1.0)
    realce_brillo = ImageEnhance.Brightness(imagen_contraste)
    imagen_oscurecida = realce_brillo.enhance(factor_brillo)

    # Aumentar la nitidez de la imagen
    factor_nitidez = 1  # Ajusta este valor para aumentar o disminuir la nitidez
    realce_nitidez = ImageEnhance.Sharpness(imagen_contraste)
    imagen_nitidez = realce_nitidez.enhance(factor_nitidez)

    # Ruta de la carpeta de destino para la imagen procesada
    carpeta_destino = "C:/Users/Administrator/Desktop/origen/"

    # Generar un nombre único para la imagen procesada basado en la marca de tiempo
    nombre_archivo_procesado = f"imagen_procesada_{int(time.time())}.jpg"

    # Ruta completa de la imagen procesada
    ruta_destino_procesado = os.path.join(carpeta_destino, nombre_archivo_procesado)

    # Guardar la imagen procesada en la carpeta de destino
    imagen_nitidez.save(ruta_destino_procesado, format='JPEG', quality=95)

    return ruta_destino_procesado  # Puedes devolver la ruta de la imagen procesada si es necesario

def procesar_fase2(imagen_path):

    # Ruta de la imagen de origen y destino para la Fase 2
    input_path = imagen_path
    output_path = imagen_path  # Puedes cambiar la ruta de destino si es necesario

    # Leer la imagen
    image = cv2.imread(input_path, cv2.IMREAD_COLOR)

    # Convertir a escala de grises
    grayScale = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    
    # Aplicar la lógica de la Fase 2 aquí (por ejemplo, quitar vellos)
    # Gray scale
    grayScale = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    
    # Black hat filter
    kernel = cv2.getStructuringElement(1, (10, 10))
    blackhat = cv2.morphologyEx(grayScale, cv2.MORPH_BLACKHAT, kernel)
    
    # Gaussian filter
    bhg = cv2.GaussianBlur(blackhat, (3, 3), cv2.BORDER_DEFAULT)
    
    # Binary thresholding (MASK)
    ret, mask = cv2.threshold(bhg, 10, 255, cv2.THRESH_BINARY)
    
    # Replace pixels of the mask
    dst = cv2.inpaint(image, mask, 6, cv2.INPAINT_TELEA)

    # Guardar la imagen procesada de la Fase 2 en la misma ruta
    cv2.imwrite(output_path, dst, [int(cv2.IMWRITE_JPEG_QUALITY), 90])

    return output_path

def procesar_fase3(imagen_path):
    # Ruta de la imagen de origen y destino para la Fase 3
    input_path = imagen_path

    # Nombre de archivo de salida para la Fase 3 (con extensión PNG)
    output_filename_fase3 = f"imagen_procesada_fase3_{int(time.time())}.png"
    output_path_fase3 = os.path.join("C:/Users/Administrator/Desktop/destino/", output_filename_fase3)

    # Verificar si el archivo es una imagen (JPEG, JPG, PNG)
    if imghdr.what(input_path) in ['jpeg', 'jpg', 'png']:
        # Leer la imagen
        imagen = cv2.imread(input_path)

        if imagen is not None:
            # Recortar la imagen según los márgenes especificados
            alto, ancho, _ = imagen.shape
            imagen = imagen[margen_superior:alto - margen_inferior, margen_izquierdo:ancho - margen_derecho]

            # Aplicar umbralización para segmentar los lunares o lesiones cutáneas
            gris = cv2.cvtColor(imagen, cv2.COLOR_BGR2GRAY)
            _, umbral = cv2.threshold(gris, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

            # Encontrar los contornos de los objetos en la imagen umbralizada
            contornos, _ = cv2.findContours(umbral, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            # Encontrar el contorno de área máxima
            max_area = 0
            max_contorno = None
            for contorno in contornos:
                area = cv2.contourArea(contorno)
                if area > max_area:
                    max_area = area
                    max_contorno = contorno

            # Crear una máscara en blanco con el mismo tamaño que la imagen original
            mascara = np.zeros_like(imagen, dtype=np.uint8)

            # Dibujar el contorno de área máxima en la máscara
            cv2.drawContours(mascara, [max_contorno], -1, (255, 255, 255), thickness=cv2.FILLED)

            # Ajustar el tamaño del kernel y el número de iteraciones para suavizar los bordes
            kernel_size = (6, 6)  # Ajusta el tamaño del kernel, por ejemplo, (3, 3) o (7, 7)
            dilate_iterations = 15  # Ajusta el número de iteraciones de dilatación, por ejemplo, 1 o 3
            erode_iterations = 12  # Ajusta el número de iteraciones de erosión, por ejemplo, 1 o 2

            # Aplicar operaciones de dilatación y erosión para suavizar los bordes
            kernel = np.ones(kernel_size, np.uint8)
            mascara = cv2.dilate(mascara, kernel, iterations=dilate_iterations)
            mascara = cv2.erode(mascara, kernel, iterations=erode_iterations)

            # Aplicar la máscara a la imagen original
            imagen_segmentada = cv2.bitwise_and(imagen, mascara)

            # Guardar la imagen segmentada en formato PNG con fondo transparente en la misma ruta
            cv2.imwrite(output_path_fase3, imagen_segmentada)
        else:
            print(f"Error al leer la imagen: {input_path}")
    else:
        print(f"Formato de archivo no admitido: {input_path}")

    return output_path_fase3


margen_superior = 100  
margen_inferior = 100 
margen_izquierdo = 170  
margen_derecho = 170 

if __name__ == "__main__":
    app.run(debug=True)
